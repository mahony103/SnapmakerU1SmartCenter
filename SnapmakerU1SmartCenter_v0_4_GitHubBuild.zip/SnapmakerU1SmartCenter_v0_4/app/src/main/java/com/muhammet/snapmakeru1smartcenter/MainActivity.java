package com.muhammet.snapmakeru1smartcenter;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String PREFS = "u1_settings";
    private static final String KEY_HOST = "host";
    private static final long REFRESH_MS = 3000L;

    private EditText ipInput;
    private Button connectButton, historyButton, filesButton;
    private TextView statusText, jobName, jobState, progressText, tempText, chamberText, timeText, etaText, filamentText;
    private TextView nozzle1Text, nozzle2Text, nozzle3Text, nozzle4Text;
    private TextView nozzle1Target, nozzle2Target, nozzle3Target, nozzle4Target;
    private TextView nozzle1Badge, nozzle2Badge, nozzle3Badge, nozzle4Badge;
    private TextView slot1Text, slot2Text, slot3Text, slot4Text;
    private TextView sectionTitle, contentText, connectionInfoText, layerText;
    private LinearLayout dashboard;
    private ProgressBar progress;

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private MoonrakerClient client;
    private boolean connected = false;
    private boolean refreshRunning = false;
    private boolean serviceStarted = false;
    private String lastState = "";
    private String lastFile = "";

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        ipInput = findViewById(R.id.ipInput);
        connectButton = findViewById(R.id.connectButton);
        historyButton = findViewById(R.id.historyButton);
        filesButton = findViewById(R.id.filesButton);
        statusText = findViewById(R.id.statusText);
        dashboard = findViewById(R.id.dashboard);
        jobName = findViewById(R.id.jobName);
        jobState = findViewById(R.id.jobState);
        progress = findViewById(R.id.progress);
        progressText = findViewById(R.id.progressText);
        tempText = findViewById(R.id.tempText);
        chamberText = findViewById(R.id.chamberText);
        timeText = findViewById(R.id.timeText);
        etaText = findViewById(R.id.etaText);
        filamentText = findViewById(R.id.filamentText);
        layerText = findViewById(R.id.layerText);
        nozzle1Text = findViewById(R.id.nozzle1Text); nozzle2Text = findViewById(R.id.nozzle2Text);
        nozzle3Text = findViewById(R.id.nozzle3Text); nozzle4Text = findViewById(R.id.nozzle4Text);
        nozzle1Target = findViewById(R.id.nozzle1Target); nozzle2Target = findViewById(R.id.nozzle2Target);
        nozzle3Target = findViewById(R.id.nozzle3Target); nozzle4Target = findViewById(R.id.nozzle4Target);
        nozzle1Badge = findViewById(R.id.nozzle1Badge); nozzle2Badge = findViewById(R.id.nozzle2Badge);
        nozzle3Badge = findViewById(R.id.nozzle3Badge); nozzle4Badge = findViewById(R.id.nozzle4Badge);
        slot1Text = findViewById(R.id.slot1Text); slot2Text = findViewById(R.id.slot2Text);
        slot3Text = findViewById(R.id.slot3Text); slot4Text = findViewById(R.id.slot4Text);
        sectionTitle = findViewById(R.id.sectionTitle); contentText = findViewById(R.id.contentText);
        connectionInfoText = findViewById(R.id.connectionInfoText);

        String savedHost = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_HOST, "");
        if (!savedHost.isEmpty()) ipInput.setText(savedHost);
        connectButton.setOnClickListener(v -> connect());
        historyButton.setOnClickListener(v -> loadHistory());
        filesButton.setOnClickListener(v -> loadFiles());
        requestNotifications();
    }

    private void requestNotifications() {
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
    }

    private void connect() {
        String host = MoonrakerClient.normalizeHost(ipInput.getText().toString());
        if (host.isEmpty()) { ipInput.setError("U1 IP adresini gir"); return; }
        ipInput.setText(host);
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_HOST, host).apply();
        connectButton.setEnabled(false);
        statusText.setText("● U1 aranıyor..."); statusText.setTextColor(getColor(R.color.muted));
        connectionInfoText.setText("Yerel Wi-Fi • Okuma bağlantısı kuruluyor");
        io.execute(() -> {
            Exception lastError = null;
            for (int attempt = 1; attempt <= 2; attempt++) {
                try {
                    long started = System.currentTimeMillis();
                    MoonrakerClient c = new MoonrakerClient(host);
                    JSONObject info = c.serverInfo();
                    long latency = System.currentTimeMillis() - started;
                    client = c; connected = true;
                    String state = info.optString("klippy_state", "unknown");
                    boolean klippy = info.optBoolean("klippy_connected", true);
                    runOnUiThread(() -> {
                        dashboard.setVisibility(View.VISIBLE);
                        connectButton.setEnabled(true); connectButton.setText("YENİDEN BAĞLAN");
                        setOnline(state, klippy, latency);
                        if (!serviceStarted) { startNotificationService(host); serviceStarted = true; }
                        refresh();
                    });
                    return;
                } catch (Exception e) {
                    lastError = e;
                    try { Thread.sleep(250L); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
                }
            }
            Exception error = lastError; connected = false;
            runOnUiThread(() -> {
                connectButton.setEnabled(true);
                statusText.setText("● Bağlantı başarısız"); statusText.setTextColor(getColor(R.color.danger));
                connectionInfoText.setText("Aynı Wi-Fi ağında olduğundan emin ol");
                Toast.makeText(this, "U1'e bağlanılamadı: " + (error == null ? "bilinmeyen hata" : error.getMessage()), Toast.LENGTH_LONG).show();
            });
        });
    }

    private void refresh() {
        if (!connected || client == null || refreshRunning) return;
        refreshRunning = true;
        io.execute(() -> {
            try {
                JSONObject root = client.printerStatus();
                JSONObject s = root.optJSONObject("result"); if (s == null) s = root;
                JSONObject status = s.optJSONObject("status"); if (status == null) status = s;
                JSONObject webhooks = status.optJSONObject("webhooks");
                JSONObject vsd = status.optJSONObject("virtual_sdcard");
                JSONObject stats = status.optJSONObject("print_stats");
                JSONObject bed = status.optJSONObject("heater_bed");
                JSONObject toolhead = status.optJSONObject("toolhead");
                JSONObject task = status.optJSONObject("print_task_config");
                String activeExtruder = toolhead != null ? toolhead.optString("extruder", "extruder") : "extruder";
                String printerState = webhooks != null ? webhooks.optString("state", "unknown") : "unknown";
                String printerMessage = webhooks != null ? webhooks.optString("state_message", "") : "";
                String printState = stats != null ? stats.optString("state", "standby") : "standby";
                String printMessage = stats != null ? stats.optString("message", "") : "";
                String file = stats != null ? stats.optString("filename", "") : "";
                double prog = vsd != null ? clamp(vsd.optDouble("progress", 0), 0, 1) : 0;
                double n1 = temp(status, "extruder"), n2 = temp(status, "extruder1"), n3 = temp(status, "extruder2"), n4 = temp(status, "extruder3");
                double t1 = targetTemp(status, "extruder"), t2 = targetTemp(status, "extruder1"), t3 = targetTemp(status, "extruder2"), t4 = targetTemp(status, "extruder3");
                double bedTemp = bed != null ? bed.optDouble("temperature", Double.NaN) : Double.NaN;
                double chamber = temp(status, "temperature_sensor cavity");
                double duration = stats != null ? stats.optDouble("total_duration", 0) : 0;
                double filamentMm = stats != null ? stats.optDouble("filament_used", 0) : 0;
                JSONObject info = stats != null ? stats.optJSONObject("info") : null;
                double filamentGrams = extractWeightGrams(info);
                if (Double.isNaN(filamentGrams)) filamentGrams = mmToGrams(filamentMm, materialForActive(task, activeExtruder));
                double eta = prog > 0.01 && prog < 1 ? duration * (1.0 - prog) / prog : 0;
                final double displayFilamentGrams = filamentGrams;
                int currentLayer = info != null ? info.optInt("current_layer", 0) : 0;
                int totalLayer = info != null ? info.optInt("total_layer", info.optInt("total_layers", 0)) : 0;
                String[] colors = slotColors(task);
                String[] materials = slotMaterials(task);

                runOnUiThread(() -> {
                    setOnline(printerState, true, -1);
                    jobName.setText(file.isEmpty() ? "Baskı yok" : file);
                    jobState.setText(stateLabel(printState) + (printMessage.isEmpty() ? "" : " • " + printMessage));
                    progress.setProgress((int)Math.round(prog * 100));
                    progressText.setText(String.format(Locale.US, "%%%d", Math.round(prog * 100)));
                    tempText.setText("Tabla: " + fmtTemp(bedTemp) + " °C");
                    chamberText.setText("Kabin: " + fmtTemp(chamber) + " °C");
                    timeText.setText("Geçen süre: " + formatDuration(duration));
                    etaText.setText("Tahmini kalan: " + (eta > 0 ? formatDuration(eta) : "--:--:--"));
                    filamentText.setText("Filament: " + String.format(Locale.US, "%.1f g", displayFilamentGrams) + " (tahmini)");
                    layerText.setText(totalLayer > 0 ? "Katman: " + currentLayer + " / " + totalLayer : "Katman: --");
                    bindNozzle(nozzle1Text, nozzle1Target, nozzle1Badge, 1, n1, t1, activeExtruder.equals("extruder"));
                    bindNozzle(nozzle2Text, nozzle2Target, nozzle2Badge, 2, n2, t2, activeExtruder.equals("extruder1"));
                    bindNozzle(nozzle3Text, nozzle3Target, nozzle3Badge, 3, n3, t3, activeExtruder.equals("extruder2"));
                    bindNozzle(nozzle4Text, nozzle4Target, nozzle4Badge, 4, n4, t4, activeExtruder.equals("extruder3"));
                    bindSlot(slot1Text, 1, colors[0], materials[0]); bindSlot(slot2Text, 2, colors[1], materials[1]);
                    bindSlot(slot3Text, 3, colors[2], materials[2]); bindSlot(slot4Text, 4, colors[3], materials[3]);
                    if (!printerMessage.isEmpty() && !"ready".equals(printerState)) connectionInfoText.setText("U1: " + printerMessage);
                    else connectionInfoText.setText("Yerel Wi-Fi • Salt okunur • 3 sn yenileme");
                    lastFile = file; lastState = printState;
                });
            } catch (Exception e) {
                connected = false;
                runOnUiThread(() -> { statusText.setText("● Bağlantı kesildi"); statusText.setTextColor(getColor(R.color.danger)); connectionInfoText.setText("U1'e yeniden bağlanmak için butona bas"); });
            } finally { refreshRunning = false; }
        });
    }

    private JSONObject object(JSONObject status, String key) {
        JSONObject o = status.optJSONObject(key); if (o != null) return o;
        JSONObject result = status.optJSONObject("result");
        if (result != null) { o = result.optJSONObject(key); if (o != null) return o; }
        return null;
    }
    private double temp(JSONObject status, String key) { JSONObject o = object(status, key); return o == null ? Double.NaN : o.optDouble("temperature", Double.NaN); }
    private double targetTemp(JSONObject status, String key) { JSONObject o = object(status, key); return o == null ? Double.NaN : o.optDouble("target", Double.NaN); }

    private void bindNozzle(TextView value, TextView target, TextView badge, int number, double current, double requested, boolean active) {
        value.setText("Nozzle " + number + "  " + fmtTemp(current) + " °C");
        target.setText("Hedef: " + fmtTemp(requested) + " °C");
        if (Double.isNaN(current)) { badge.setText("VERİ YOK"); badge.setTextColor(getColor(R.color.muted)); }
        else if (active) { badge.setText("AKTİF"); badge.setTextColor(getColor(R.color.accent)); }
        else if (!Double.isNaN(requested) && requested > 0) { badge.setText("HAZIRLANIYOR"); badge.setTextColor(getColor(R.color.accent)); }
        else { badge.setText("BEKLEMEDE"); badge.setTextColor(getColor(R.color.muted)); }
    }

    private void bindSlot(TextView view, int slot, String hex, String material) {
        String name = colorName(hex);
        view.setText("Slot " + slot + "  •  " + name + "\n" + material);
        try { view.setTextColor(Color.parseColor(hex)); } catch (Exception e) { view.setTextColor(getColor(R.color.text)); }
        if ("#FFFFFF".equalsIgnoreCase(hex)) view.setTextColor(getColor(R.color.text));
    }

    private String[] slotColors(JSONObject task) {
        String[] out = {"#FFFFFF", "#FFFFFF", "#FFFFFF", "#FFFFFF"};
        if (task == null) return out;
        JSONArray a = task.optJSONArray("filament_color_rgba");
        if (a == null) a = task.optJSONArray("filament_color");
        if (a != null) for (int i=0;i<4 && i<a.length();i++) out[i] = normalizeHex(a.optString(i, "#FFFFFF"));
        return out;
    }
    private String[] slotMaterials(JSONObject task) {
        String[] out = {"Filament", "Filament", "Filament", "Filament"};
        if (task == null) return out;
        JSONArray types = task.optJSONArray("filament_type"); JSONArray vendors = task.optJSONArray("filament_vendor");
        JSONArray subs = task.optJSONArray("filament_sub_type");
        for (int i=0;i<4;i++) {
            String v = vendors != null ? vendors.optString(i, "") : "";
            String t = types != null ? types.optString(i, "") : "";
            String s = subs != null ? subs.optString(i, "") : "";
            String x = (v.isEmpty() || "NONE".equalsIgnoreCase(v)) ? "" : v + " ";
            x += (t.isEmpty() || "NONE".equalsIgnoreCase(t)) ? "Filament" : t;
            if (!s.isEmpty() && !"NONE".equalsIgnoreCase(s)) x += " " + s;
            out[i] = x;
        }
        return out;
    }
    private String normalizeHex(String s) {
        if (s == null || s.isEmpty()) return "#FFFFFF";
        s = s.trim();
        if (s.contains(";")) s = s.split(";")[0];
        if (s.length() >= 6) {
            if (s.startsWith("#")) return s.length() >= 7 ? s.substring(0,7) : "#FFFFFF";
            return "#" + s.substring(0,6);
        }
        return "#FFFFFF";
    }
    private String colorName(String hex) {
        try {
            int c = Color.parseColor(hex); int r=Color.red(c), g=Color.green(c), b=Color.blue(c);
            int[][] base={{255,0,0},{255,255,255},{0,0,0},{0,0,255},{0,128,0},{255,255,0},{255,165,0},{128,0,128},{255,192,203},{128,128,128},{165,42,42},{0,255,255}};
            String[] names={"Kırmızı","Beyaz","Siyah","Mavi","Yeşil","Sarı","Turuncu","Mor","Pembe","Gri","Kahverengi","Camgöbeği"};
            int best=0, dist=Integer.MAX_VALUE;
            for(int i=0;i<base.length;i++){int dr=r-base[i][0],dg=g-base[i][1],db=b-base[i][2];int d=dr*dr+dg*dg+db*db;if(d<dist){dist=d;best=i;}}
            return names[best];
        } catch(Exception e){return hex;}
    }

    private String materialForActive(JSONObject task, String activeExtruder) {
        if (task == null) return "PLA";
        int idx = activeExtruder.equals("extruder1") ? 1 : activeExtruder.equals("extruder2") ? 2 : activeExtruder.equals("extruder3") ? 3 : 0;
        JSONArray a=task.optJSONArray("filament_type"); return a == null ? "PLA" : a.optString(idx,"PLA");
    }
    private double densityFor(String type) {
        String t = type == null ? "PLA" : type.toUpperCase(Locale.US);
        if (t.contains("ABS")) return 1.04;
        if (t.contains("ASA")) return 1.07;
        if (t.contains("PETG")) return 1.27;
        if (t.contains("TPU") || t.contains("TPE")) return 1.20;
        if (t.contains("PA") || t.contains("NYLON")) return 1.14;
        if (t.contains("PC")) return 1.20;
        if (t.contains("PLA")) return 1.24;
        return 1.24;
    }
    private double mmToGrams(double mm, String material) {
        if (mm <= 0) return 0;
        double radius=1.75/2.0; // U1 nominal filament diameter
        double volumeCm3 = Math.PI*radius*radius*mm/1000.0;
        return volumeCm3*densityFor(material);
    }
    private double extractWeightGrams(JSONObject info) {
        if (info == null) return Double.NaN;
        String[] keys={"filament_weight_used","filament_used_weight","filament_weight"};
        for(String k:keys){ if(info.has(k)){ double v=info.optDouble(k,Double.NaN); if(!Double.isNaN(v)&&v>0)return v; }}
        return Double.NaN;
    }

    private void setOnline(String state, boolean klippyConnected, long latency) {
        statusText.setText("● U1 ONLINE • " + (klippyConnected ? state : "Klippy bağlantısı yok"));
        statusText.setTextColor(getColor(R.color.accent));
        if (latency >= 0) connectionInfoText.setText("Yerel Wi-Fi • " + latency + " ms • Salt okunur");
    }
    private String stateLabel(String s) { switch(s){case "printing":return "Baskı yapılıyor";case "paused":return "Baskı duraklatıldı";case "complete":return "Baskı tamamlandı";case "cancelled":return "Baskı iptal edildi";case "error":return "Baskı hatası";default:return "Hazır";} }
    private String fmtTemp(double x){return Double.isNaN(x)?"--":String.format(Locale.US,"%.0f",x);}
    private String formatDuration(double sec){long s=(long)Math.max(0,sec);long h=s/3600,m=(s%3600)/60,ss=s%60;return String.format(Locale.US,"%02d:%02d:%02d",h,m,ss);}
    private double clamp(double v,double min,double max){return Math.max(min,Math.min(max,v));}

    private void loadHistory() {
        if (!connected || client == null) return;
        sectionTitle.setText("Baskı geçmişi"); contentText.setText("Yükleniyor...");
        io.execute(() -> {
            try {
                JSONArray jobs=client.history(30); StringBuilder out=new StringBuilder();
                if(jobs==null||jobs.length()==0) out.append("Henüz kayıt yok.");
                else for(int i=0;i<jobs.length();i++){
                    JSONObject j=jobs.getJSONObject(i); String name=j.optString("filename","Bilinmeyen");
                    String state=j.optString("status",j.optString("state","")); double duration=j.optDouble("print_duration",j.optDouble("total_duration",0));
                    double mm=j.optDouble("filament_used",0); double grams=Double.NaN; String color="Renk bilgisi yok"; String material="PLA";
                    try { JSONObject m=client.metadata(name); grams=metadataWeight(m); color=metadataColor(m); material=m.optString("filament_type",material); } catch(Exception ignored) {}
                    if(Double.isNaN(grams)) grams=mmToGrams(mm,material);
                    out.append("• ").append(name).append("\n");
                    out.append("  ").append(stateLabel(state)).append(" • ").append(formatDuration(duration)).append("\n");
                    out.append("  Filament: ").append(String.format(Locale.US,"%.1f g",grams)).append(" (tahmini) • ").append(color).append("\n\n");
                }
                String result=out.toString(); runOnUiThread(()->contentText.setText(result));
            }catch(Exception e){runOnUiThread(()->contentText.setText("Geçmiş alınamadı:\n"+e.getMessage()));}
        });
    }

    private double metadataWeight(JSONObject m){
        String[] keys={"filament_weight_total","filament_weight","filament_used_weight"};
        for(String k:keys){double v=m.optDouble(k,Double.NaN);if(!Double.isNaN(v)&&v>0)return v;}
        return Double.NaN;
    }
    private String metadataColor(JSONObject m){
        String[] keys={"filament_colour","filament_color","filament_color_rgba"};
        for(String k:keys){String s=m.optString(k,"");if(!s.isEmpty())return colorName(normalizeHex(s));}
        return "Renk bilgisi yok";
    }

    private void loadFiles() {
        if(!connected||client==null)return; sectionTitle.setText("G-Code dosyaları");contentText.setText("Yükleniyor...");
        io.execute(()->{try{JSONArray arr=client.files();StringBuilder out=new StringBuilder();final String[] paths=new String[arr.length()];for(int i=0;i<arr.length();i++){JSONObject f=arr.getJSONObject(i);String path=f.optString("path","");paths[i]=path;out.append("• ").append(path).append("  (").append(humanSize(f.optLong("size",0))).append(")\n");}if(arr.length()==0)out.append("G-Code dosyası bulunamadı.");runOnUiThread(()->{contentText.setText(out.toString());filesButton.setOnClickListener(v->showFilePicker(paths));});}catch(Exception e){runOnUiThread(()->contentText.setText("G-Code listesi alınamadı:\n"+e.getMessage()));}});
    }
    private void showFilePicker(String[] paths){if(paths.length==0){Toast.makeText(this,"G-Code dosyası yok.",Toast.LENGTH_SHORT).show();return;}new AlertDialog.Builder(this).setTitle("G-Code analiz et").setItems(paths,(d,w)->loadMetadata(paths[w])).setNegativeButton("Kapat",null).show();}
    private void loadMetadata(String filename){contentText.setText("Analiz ediliyor...");sectionTitle.setText("G-Code analizi");io.execute(()->{try{JSONObject m=client.metadata(filename);StringBuilder x=new StringBuilder();x.append("📄 ").append(m.optString("filename",filename)).append("\n\n");x.append("Slicer: ").append(m.optString("slicer","--")).append("\n");x.append("Tahmini süre: ").append(formatDuration(m.optDouble("estimated_time",0))).append("\n");double mw = metadataWeight(m);
                x.append("Filament ağırlığı: ").append(Double.isNaN(mw) ? "--" : String.format(Locale.US,"%.1f g",mw)).append("\n");x.append("Filament rengi: ").append(metadataColor(m)).append("\n");x.append("Filament tipi: ").append(m.optString("filament_type","--")).append("\n");x.append("İlk katman nozzle: ").append(m.optString("first_layer_extr_temp","--")).append(" °C\n");x.append("İlk katman tabla: ").append(m.optString("first_layer_bed_temp","--")).append(" °C\n\n");x.append("🛡️ Yazıcıya komut gönderilmedi.");runOnUiThread(()->contentText.setText(x.toString()));}catch(Exception e){runOnUiThread(()->contentText.setText("G-Code analizi alınamadı:\n"+e.getMessage()));}});}
    private String humanSize(long n){if(n<1024)return n+" B";if(n<1024*1024)return String.format(Locale.US,"%.1f KB",n/1024.0);return String.format(Locale.US,"%.1f MB",n/1024.0/1024.0);}
    private void startNotificationService(String host){Intent i=new Intent(this,NotificationService.class);i.putExtra("host",host);if(android.os.Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);}
    private final Runnable ticker=new Runnable(){@Override public void run(){if(connected)refresh();handler.postDelayed(this,REFRESH_MS);}};
    @Override protected void onResume(){super.onResume();handler.removeCallbacks(ticker);handler.post(ticker);}
    @Override protected void onPause(){super.onPause();handler.removeCallbacks(ticker);}
    @Override protected void onDestroy(){handler.removeCallbacks(ticker);io.shutdownNow();super.onDestroy();}
}
