package com.muhammet.snapmakeru1smartcenter;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MoonrakerClient {
    private final String base;

    public MoonrakerClient(String host) {
        host = host.trim();
        if (host.startsWith("http://")) host = host.substring(7);
        if (host.endsWith("/")) host = host.substring(0, host.length() - 1);
        this.base = "http://" + host;
    }

    private String get(String path) throws Exception {
        URL url = new URL(base + path);
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setConnectTimeout(4000);
        c.setReadTimeout(6000);
        c.setRequestMethod("GET");
        c.setRequestProperty("Accept", "application/json");
        int code = c.getResponseCode();
        InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        StringBuilder b = new StringBuilder();
        if (in != null) {
            BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
            String line;
            while ((line = r.readLine()) != null) b.append(line);
            r.close();
        }
        c.disconnect();
        if (code < 200 || code >= 300) throw new Exception("HTTP " + code + ": " + b);
        return b.toString();
    }

    public JSONObject serverInfo() throws Exception {
        return new JSONObject(get("/server/info"));
    }

    public JSONObject printerStatus() throws Exception {
        return new JSONObject(get("/printer/objects/query?webhooks&virtual_sdcard&print_stats&extruder&heater_bed"));
    }

    public JSONArray history(int limit) throws Exception {
        JSONObject root = new JSONObject(get("/server/history/list?limit=" + limit + "&order=desc"));
        JSONObject result = root.optJSONObject("result");
        if (result != null) return result.optJSONArray("jobs");
        return root.optJSONArray("jobs");
    }

    public JSONArray files() throws Exception {
        return new JSONArray(get("/server/files/list?root=gcodes"));
    }

    public JSONObject metadata(String filename) throws Exception {
        return new JSONObject(get("/server/files/metadata?filename=" +
                URLEncoder.encode(filename, StandardCharsets.UTF_8.toString())));
    }
}
