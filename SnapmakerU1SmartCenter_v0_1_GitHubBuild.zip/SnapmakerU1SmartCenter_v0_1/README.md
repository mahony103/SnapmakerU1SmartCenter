# Snapmaker U1 Smart Center v0.1

A separate Android app for Snapmaker U1. It does NOT depend on the user's previous filament/cost application.

## Safety scope
v0.1 is intentionally read-only with respect to the printer:
- No firmware changes
- No Klipper configuration changes
- No G-code commands sent to the printer
- No pause/resume/stop/start commands
- No MCU access

It reads the local Moonraker HTTP API only.

## Implemented
1. U1 Smart Dashboard
2. Print history
5. Phone notifications for print state changes
7. G-code file listing
8. G-code metadata analyzer foundation (metadata API is wired; UI expansion is next)

The current version keeps all printer operations read-only; file deletion/start/stop/pause commands are intentionally absent.

## Connection
Phone and U1 should be on the same local Wi-Fi network. Enter the U1 IP address, e.g.:
192.168.1.50

The app uses local HTTP to Moonraker.

## Build
Open this folder in Android Studio and let Gradle sync. No third-party runtime libraries are required.

## Important
This project has not been tested against the user's physical U1 in this environment. The first real-device test should be read-only connectivity and status retrieval.


## GitHub Actions
Bu proje bilgisayar/Android Studio olmadan GitHub Actions üzerinde derlenebilir.
Workflow: `.github/workflows/build-apk.yml`
Derleme sonunda `SnapmakerU1SmartCenter-debug` adlı artifact içinde `app-debug.apk` oluşur.
