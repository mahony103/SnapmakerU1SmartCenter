# Snapmaker U1 Smart Center v0.2

Separate Android app for Snapmaker U1. It is independent from the previous filament/finance app.

## Safety scope
v0.2 remains read-only with respect to the printer:
- No firmware changes
- No Klipper configuration changes
- No G-code commands sent to the printer
- No pause/resume/stop/start commands
- No file upload/delete commands
- No MCU access

The app only reads the local Moonraker HTTP API.

## v0.2 changes
- More reliable local-LAN connection with a short retry.
- Remembers the last U1 IP address.
- 3-second read-only dashboard refresh without overlapping requests.
- Reads the four U1 toolhead temperature objects when available.
- Reads bed and chamber temperature when available.
- Shows Moonraker/Klipper state messages when available.
- More tolerant parsing of Moonraker `result` wrappers for history/files/metadata.
- Notification polling reduced to 10 seconds to minimize phone-side background work.
- G-Code metadata remains read-only.

Moonraker documents `GET /server/info` and `GET /printer/objects/query` for status, and `/server/files/list` / `/server/files/metadata` for read-only file information. The U1 uses four extruder objects (`extruder` through `extruder3`).

## Connection
Phone and U1 must currently be on the same local Wi-Fi network. Enter the U1's local IP, for example `192.168.0.104`.

## Build
GitHub Actions builds the debug APK from `.github/workflows/build-apk.yml`.
Artifact: `SnapmakerU1SmartCenter-debug` -> `app-debug.apk`.
