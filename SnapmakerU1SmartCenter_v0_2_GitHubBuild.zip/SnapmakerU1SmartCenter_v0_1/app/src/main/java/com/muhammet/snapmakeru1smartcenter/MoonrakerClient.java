package com.muhammet.snapmakeru1smartcenter;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/**
 * Read-only Moonraker client for the Snapmaker U1.
 * No printer control endpoints are implemented here.
 */
public class MoonrakerClient {
    private final String base;

    public MoonrakerClient(String host) {
        host = normalizeHost(host);
        this.base = "http://" + host;
    }

    public static String normalizeHost(String host) {
        host = host == null ? "" : host.trim();
        if (host.startsWith("http://")) host = host.substring(7);
        if (host.startsWith("https://")) host = host.substring(8);
        while (host.endsWith("/")) host = host.substring(0, host.length() - 1);
        if (host.endsWith(":80")) host = host.substring(0, host.length() - 3);
        return host;
    }

    private String get(String path) throws Exception {
        URL url = new URL(base + path);
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setConnectTimeout(3000);
        c.setReadTimeout(5000);
        c.setUseCaches(false);
        c.setRequestMethod("GET");
        c.setRequestProperty("Accept", "application/json");
        int code = c.getResponseCode();
        InputStream in = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        StringBuilder b = new StringBuilder();
        if (in != null) {
            try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                String line;
                while ((line = r.readLine()) != null) b.append(line);
            }
        }
        c.disconnect();
        if (code < 200 || code >= 300) throw new Exception("HTTP " + code + ": " + b);
        return b.toString();
    }

    public JSONObject serverInfo() throws Exception {
        return new JSONObject(get("/server/info"));
    }

    public JSONObject printerInfo() throws Exception {
        return new JSONObject(get("/printer/info"));
    }

    public JSONObject printerStatus() throws Exception {
        // U1 is a four-toolhead machine. Requesting only telemetry objects keeps
        // the response small and avoids any write/control operation.
        return new JSONObject(get("/printer/objects/query"
                + "?webhooks&virtual_sdcard&print_stats"
                + "&extruder&extruder1&extruder2&extruder3"
                + "&heater_bed&temperature_sensor%20chamber"));
    }

    public JSONArray history(int limit) throws Exception {
        JSONObject root = new JSONObject(get("/server/history/list?limit=" + limit + "&order=desc"));
        JSONArray direct = root.optJSONArray("result");
        if (direct != null) return direct;
        JSONObject result = root.optJSONObject("result");
        if (result != null) return result.optJSONArray("jobs");
        return root.optJSONArray("jobs");
    }

    public JSONArray files() throws Exception {
        String raw = get("/server/files/list?root=gcodes");
        try {
            return new JSONArray(raw);
        } catch (Exception ignored) {
            JSONObject root = new JSONObject(raw);
            JSONArray result = root.optJSONArray("result");
            if (result != null) return result;
            JSONObject obj = root.optJSONObject("result");
            return obj != null ? obj.optJSONArray("files") : new JSONArray();
        }
    }

    public JSONObject metadata(String filename) throws Exception {
        String encoded = URLEncoder.encode(filename, StandardCharsets.UTF_8.toString()).replace("+", "%20");
        String raw = get("/server/files/metadata?filename=" + encoded);
        JSONObject root = new JSONObject(raw);
        JSONObject result = root.optJSONObject("result");
        return result != null ? result : root;
    }
}
