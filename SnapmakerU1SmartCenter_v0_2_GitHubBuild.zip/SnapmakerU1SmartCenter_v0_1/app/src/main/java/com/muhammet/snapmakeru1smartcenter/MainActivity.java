package com.muhammet.snapmakeru1smartcenter;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String PREFS = "u1_settings";
    private static final String KEY_HOST = "host";
    private static final long REFRESH_MS = 3000L;

    private EditText ipInput;
    private Button connectButton, historyButton, filesButton;
    private TextView statusText, jobName, jobState, progressText, tempText, timeText, filamentText;
    private TextView nozzle1Text, nozzle2Text, nozzle3Text, nozzle4Text, chamberText;
    private TextView sectionTitle, contentText, connectionInfoText;
    private LinearLayout dashboard;
    private ProgressBar progress;

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private MoonrakerClient client;
    private boolean connected = false;
    private boolean refreshRunning = false;
    private boolean serviceStarted = false;
    private String lastState = "";
    private String lastFile = "";

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        ipInput = findViewById(R.id.ipInput);
        connectButton = findViewById(R.id.connectButton);
        historyButton = findViewById(R.id.historyButton);
        filesButton = findViewById(R.id.filesButton);
        statusText = findViewById(R.id.statusText);
        dashboard = findViewById(R.id.dashboard);
        jobName = findViewById(R.id.jobName);
        jobState = findViewById(R.id.jobState);
        progress = findViewById(R.id.progress);
        progressText = findViewById(R.id.progressText);
        tempText = findViewById(R.id.tempText);
        timeText = findViewById(R.id.timeText);
        filamentText = findViewById(R.id.filamentText);
        nozzle1Text = findViewById(R.id.nozzle1Text);
        nozzle2Text = findViewById(R.id.nozzle2Text);
        nozzle3Text = findViewById(R.id.nozzle3Text);
        nozzle4Text = findViewById(R.id.nozzle4Text);
        chamberText = findViewById(R.id.chamberText);
        sectionTitle = findViewById(R.id.sectionTitle);
        contentText = findViewById(R.id.contentText);
        connectionInfoText = findViewById(R.id.connectionInfoText);

        SharedPreferences settings = getSharedPreferences(PREFS, MODE_PRIVATE);
        String savedHost = settings.getString(KEY_HOST, "");
        if (!savedHost.isEmpty()) ipInput.setText(savedHost);

        connectButton.setOnClickListener(v -> connect());
        historyButton.setOnClickListener(v -> loadHistory());
        filesButton.setOnClickListener(v -> loadFiles());

        requestNotifications();
    }

    private void requestNotifications() {
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        }
    }

    private void connect() {
        String host = MoonrakerClient.normalizeHost(ipInput.getText().toString());
        if (host.isEmpty()) {
            ipInput.setError("U1 IP adresini gir");
            return;
        }

        ipInput.setText(host);
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_HOST, host).apply();
        connectButton.setEnabled(false);
        statusText.setText("● U1 aranıyor...");
        statusText.setTextColor(getColor(R.color.muted));
        connectionInfoText.setText("Yerel Wi-Fi • Okuma bağlantısı kuruluyor");

        io.execute(() -> {
            Exception lastError = null;
            for (int attempt = 1; attempt <= 2; attempt++) {
                try {
                    long started = System.currentTimeMillis();
                    MoonrakerClient c = new MoonrakerClient(host);
                    JSONObject info = c.serverInfo();
                    long latency = System.currentTimeMillis() - started;
                    client = c;
                    connected = true;
                    String state = info.optString("klippy_state", "unknown");
                    boolean klippy = info.optBoolean("klippy_connected", true);
                    runOnUiThread(() -> {
                        dashboard.setVisibility(View.VISIBLE);
                        connectButton.setEnabled(true);
                        connectButton.setText("YENİDEN BAĞLAN");
                        setOnline(state, klippy, latency);
                        if (!serviceStarted) {
                            startNotificationService(host);
                            serviceStarted = true;
                        }
                        refresh();
                    });
                    return;
                } catch (Exception e) {
                    lastError = e;
                    try { Thread.sleep(250L); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
                }
            }
            connected = false;
            Exception error = lastError;
            runOnUiThread(() -> {
                connectButton.setEnabled(true);
                statusText.setText("● Bağlantı başarısız");
                statusText.setTextColor(getColor(R.color.danger));
                connectionInfoText.setText("Aynı Wi-Fi ağında olduğundan emin ol");
                Toast.makeText(this, "U1'e bağlanılamadı: " + (error == null ? "bilinmeyen hata" : error.getMessage()), Toast.LENGTH_LONG).show();
            });
        });
    }

    private void refresh() {
        if (!connected || client == null || refreshRunning) return;
        refreshRunning = true;
        io.execute(() -> {
            try {
                JSONObject root = client.printerStatus();
                JSONObject s = root.optJSONObject("result");
                if (s == null) s = root;
                JSONObject status = s.optJSONObject("status");
                if (status == null) status = s;

                JSONObject webhooks = status.optJSONObject("webhooks");
                JSONObject vsd = status.optJSONObject("virtual_sdcard");
                JSONObject stats = status.optJSONObject("print_stats");
                JSONObject bed = status.optJSONObject("heater_bed");

                String printerState = webhooks != null ? webhooks.optString("state", "unknown") : "unknown";
                String printerMessage = webhooks != null ? webhooks.optString("state_message", "") : "";
                String printState = stats != null ? stats.optString("state", "standby") : "standby";
                String printMessage = stats != null ? stats.optString("message", "") : "";
                String file = stats != null ? stats.optString("filename", "") : "";
                double prog = vsd != null ? clamp(vsd.optDouble("progress", 0), 0, 1) : 0;
                double nozzle1 = temp(status, "extruder");
                double nozzle2 = temp(status, "extruder1");
                double nozzle3 = temp(status, "extruder2");
                double nozzle4 = temp(status, "extruder3");
                double bedTemp = bed != null ? bed.optDouble("temperature", Double.NaN) : Double.NaN;
                double chamber = temp(status, "temperature_sensor chamber");
                double duration = stats != null ? stats.optDouble("total_duration", 0) : 0;
                double filament = stats != null ? stats.optDouble("filament_used", 0) : 0;
                boolean stateChanged = !file.equals(lastFile) || !printState.equals(lastState);

                runOnUiThread(() -> {
                    setOnline(printerState, true, -1);
                    jobName.setText(file.isEmpty() ? "Baskı yok" : file);
                    jobState.setText(stateLabel(printState));
                    if (!printMessage.isEmpty() && "error".equals(printState)) {
                        jobState.setText(stateLabel(printState) + " • " + printMessage);
                    }
                    progress.setProgress((int)Math.round(prog * 100));
                    progressText.setText(String.format(Locale.US, "%%%d", Math.round(prog * 100)));
                    tempText.setText(String.format(Locale.US, "Tabla: %s °C", fmtTemp(bedTemp)));
                    timeText.setText("Geçen süre: " + formatDuration(duration));
                    filamentText.setText("Filament: " + String.format(Locale.US, "%.1f mm", filament));
                    nozzle1Text.setText("Nozzle 1: " + fmtTemp(nozzle1) + " °C");
                    nozzle2Text.setText("Nozzle 2: " + fmtTemp(nozzle2) + " °C");
                    nozzle3Text.setText("Nozzle 3: " + fmtTemp(nozzle3) + " °C");
                    nozzle4Text.setText("Nozzle 4: " + fmtTemp(nozzle4) + " °C");
                    chamberText.setText("Hazne: " + fmtTemp(chamber) + " °C");
                    if (!printerMessage.isEmpty() && !"ready".equals(printerState)) {
                        connectionInfoText.setText("U1: " + printerMessage);
                    } else {
                        connectionInfoText.setText("Yerel Wi-Fi • Salt okunur bağlantı • 3 sn");
                    }
                    if (stateChanged) {
                        lastFile = file;
                        lastState = printState;
                    }
                });
            } catch (Exception e) {
                connected = false;
                runOnUiThread(() -> {
                    statusText.setText("● Bağlantı kesildi");
                    statusText.setTextColor(getColor(R.color.danger));
                    connectionInfoText.setText("U1'e yeniden bağlanmak için butona bas");
                });
            } finally {
                refreshRunning = false;
            }
        });
    }

    private double temp(JSONObject status, String key) {
        JSONObject o = status.optJSONObject(key);
        return o == null ? Double.NaN : o.optDouble("temperature", Double.NaN);
    }

    private double clamp(double v, double min, double max) {
        return Math.max(min, Math.min(max, v));
    }

    private void setOnline(String state, boolean klippyConnected, long latency) {
        String suffix = klippyConnected ? state : "Klippy bağlantısı yok";
        statusText.setText("● U1 ONLINE • " + suffix);
        statusText.setTextColor(getColor(R.color.accent));
        if (latency >= 0) connectionInfoText.setText("Yerel Wi-Fi • " + latency + " ms • Salt okunur");
    }

    private String stateLabel(String s) {
        switch (s) {
            case "printing": return "Baskı yapılıyor";
            case "paused": return "Baskı duraklatıldı";
            case "complete": return "Baskı tamamlandı";
            case "cancelled": return "Baskı iptal edildi";
            case "error": return "Baskı hatası";
            default: return "Hazır";
        }
    }

    private String fmtTemp(double x) {
        return Double.isNaN(x) ? "--" : String.format(Locale.US, "%.0f", x);
    }

    private String formatDuration(double sec) {
        long s = (long) Math.max(0, sec);
        long h = s / 3600; long m = (s % 3600) / 60; long ss = s % 60;
        return String.format(Locale.US, "%02d:%02d:%02d", h, m, ss);
    }

    private void loadHistory() {
        if (!connected || client == null) return;
        sectionTitle.setText("Baskı geçmişi");
        contentText.setText("Yükleniyor...");
        io.execute(() -> {
            try {
                JSONArray jobs = client.history(30);
                StringBuilder out = new StringBuilder();
                if (jobs == null || jobs.length() == 0) out.append("Henüz kayıt yok.");
                else {
                    for (int i = 0; i < jobs.length(); i++) {
                        JSONObject j = jobs.getJSONObject(i);
                        String name = j.optString("filename", "Bilinmeyen");
                        String state = j.optString("status", j.optString("state", ""));
                        double duration = j.optDouble("print_duration", j.optDouble("total_duration", 0));
                        double filament = j.optDouble("filament_used", 0);
                        out.append("• ").append(name).append("\n");
                        out.append("  ").append(stateLabel(state)).append(" • ")
                                .append(formatDuration(duration)).append(" • ")
                                .append(String.format(Locale.US, "%.1f mm", filament)).append("\n\n");
                    }
                }
                runOnUiThread(() -> contentText.setText(out.toString()));
            } catch (Exception e) {
                runOnUiThread(() -> contentText.setText("Geçmiş alınamadı:\n" + e.getMessage()));
            }
        });
    }

    private void loadFiles() {
        if (!connected || client == null) return;
        sectionTitle.setText("G-Code dosyaları");
        contentText.setText("Yükleniyor...");
        io.execute(() -> {
            try {
                JSONArray arr = client.files();
                StringBuilder out = new StringBuilder();
                final String[] paths = new String[arr.length()];
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject f = arr.getJSONObject(i);
                    String path = f.optString("path", "");
                    paths[i] = path;
                    out.append("• ").append(path)
                            .append("  (").append(humanSize(f.optLong("size", 0))).append(")\n");
                }
                if (arr.length() == 0) out.append("G-Code dosyası bulunamadı.");
                runOnUiThread(() -> {
                    contentText.setText(out.toString());
                    filesButton.setOnClickListener(v -> showFilePicker(paths));
                });
            } catch (Exception e) {
                runOnUiThread(() -> contentText.setText("G-Code listesi alınamadı:\n" + e.getMessage()));
            }
        });
    }

    private void showFilePicker(String[] paths) {
        if (paths.length == 0) {
            Toast.makeText(this, "G-Code dosyası yok.", Toast.LENGTH_SHORT).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("G-Code analiz et")
                .setItems(paths, (dialog, which) -> loadMetadata(paths[which]))
                .setNegativeButton("Kapat", null)
                .show();
    }

    private void loadMetadata(String filename) {
        contentText.setText("Analiz ediliyor...");
        sectionTitle.setText("G-Code analizi");
        io.execute(() -> {
            try {
                JSONObject m = client.metadata(filename);
                StringBuilder x = new StringBuilder();
                x.append("📄 ").append(m.optString("filename", filename)).append("\n\n");
                x.append("Slicer: ").append(m.optString("slicer", "--")).append("\n");
                x.append("Slicer sürümü: ").append(m.optString("slicer_version", "--")).append("\n");
                x.append("Tahmini süre: ").append(formatDuration(m.optDouble("estimated_time", 0))).append("\n");
                x.append("Katman yüksekliği: ").append(m.optString("layer_height", "--")).append(" mm\n");
                x.append("Nozzle: ").append(m.optString("nozzle_diameter", "--")).append(" mm\n");
                x.append("Model yüksekliği: ").append(m.optString("object_height", "--")).append(" mm\n");
                x.append("Filament: ").append(m.optString("filament_name", "--")).append("\n");
                x.append("Filament tipi: ").append(m.optString("filament_type", "--")).append("\n");
                x.append("Filament: ").append(m.optString("filament_weight_total", "--")).append(" g\n");
                x.append("Filament değişimi: ").append(m.optString("filament_change_count", "0")).append("\n");
                x.append("İlk katman nozzle: ").append(m.optString("first_layer_extr_temp", "--")).append(" °C\n");
                x.append("İlk katman tabla: ").append(m.optString("first_layer_bed_temp", "--")).append(" °C\n\n");
                x.append("🟢 Bu analiz yalnızca G-Code metadata'sını okur.\n");
                x.append("🛡️ Yazıcıya komut gönderilmedi.");
                runOnUiThread(() -> contentText.setText(x.toString()));
            } catch (Exception e) {
                runOnUiThread(() -> contentText.setText("G-Code analizi alınamadı:\n" + e.getMessage()));
            }
        });
    }

    private String humanSize(long n) {
        if (n < 1024) return n + " B";
        if (n < 1024*1024) return String.format(Locale.US, "%.1f KB", n/1024.0);
        return String.format(Locale.US, "%.1f MB", n/1024.0/1024.0);
    }

    private void startNotificationService(String host) {
        Intent i = new Intent(this, NotificationService.class);
        i.putExtra("host", host);
        if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(i);
        else startService(i);
    }

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (connected) refresh();
            handler.postDelayed(this, REFRESH_MS);
        }
    };

    @Override protected void onResume() {
        super.onResume();
        handler.removeCallbacks(ticker);
        handler.post(ticker);
    }

    @Override protected void onPause() {
        super.onPause();
        handler.removeCallbacks(ticker);
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(ticker);
        io.shutdownNow();
        super.onDestroy();
    }
}
