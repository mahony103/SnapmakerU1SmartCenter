package com.muhammet.snapmakeru1smartcenter;

import android.app.*;
import android.content.Intent;
import android.os.*;
import org.json.JSONObject;

public class NotificationService extends Service {
    private static final String CHANNEL = "u1_status";
    private static final long POLL_MS = 10000L;
    private Handler handler;
    private Runnable task;
    private String host;
    private String lastState = "";
    private String lastFile = "";
    private boolean checking = false;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        handler = new Handler(Looper.getMainLooper());
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) host = intent.getStringExtra("host");
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(7, buildNotification("U1 Smart Center aktif"),
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(7, buildNotification("U1 Smart Center aktif"));
        }
        if (task == null) {
            task = new Runnable() {
                @Override public void run() {
                    check();
                    handler.postDelayed(this, POLL_MS);
                }
            };
            handler.post(task);
        }
        return START_STICKY;
    }

    private void check() {
        if (host == null || host.isEmpty() || checking) return;
        checking = true;
        new Thread(() -> {
            try {
                MoonrakerClient c = new MoonrakerClient(host);
                JSONObject root = c.printerStatus();
                JSONObject result = root.optJSONObject("result");
                JSONObject status = result != null ? result.optJSONObject("status") : root.optJSONObject("status");
                if (status == null) return;
                JSONObject stats = status.optJSONObject("print_stats");
                if (stats == null) return;
                String state = stats.optString("state", "");
                String file = stats.optString("filename", "");
                if (!lastState.isEmpty() && !state.equals(lastState)) {
                    if ("complete".equals(state)) notifyUser("Baskı tamamlandı", file);
                    else if ("error".equals(state)) notifyUser("Baskı hatası", file);
                    else if ("cancelled".equals(state)) notifyUser("Baskı iptal edildi", file);
                }
                lastState = state;
                lastFile = file;
            } catch (Exception ignored) {
            } finally {
                checking = false;
            }
        }).start();
    }

    private void notifyUser(String title, String text) {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.notify((int)(System.currentTimeMillis() % 100000), new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Snapmaker U1 • " + title)
                .setContentText(text == null || text.isEmpty() ? "Durum değişti." : text)
                .setAutoCancel(true)
                .build());
    }

    private Notification buildNotification(String text) {
        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Snapmaker U1 Smart Center")
                .setContentText(text)
                .setOngoing(true)
                .build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "U1 bildirimleri",
                    NotificationManager.IMPORTANCE_DEFAULT);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }

    @Override public void onDestroy() {
        if (handler != null && task != null) handler.removeCallbacks(task);
        super.onDestroy();
    }

    @Override public android.os.IBinder onBind(Intent intent) { return null; }
}
