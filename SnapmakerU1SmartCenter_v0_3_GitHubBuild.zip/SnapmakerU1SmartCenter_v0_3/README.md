# Snapmaker U1 Smart Center v0.3

Bağımsız Android uygulaması. Snapmaker U1 ile aynı yerel Wi-Fi ağında, yalnızca okuma amaçlı Moonraker bağlantısı kullanır.

## v0.3
- 4 nozzle sıcaklığı ve hedef sıcaklığı
- Aktif nozzle göstergesi
- Tabla ve hazne sıcaklığı
- Baskı adı, durum ve ilerleme
- Otomatik 3 saniyelik yenileme
- Bağlantı gecikmesi ve yeniden bağlanma
- Baskı geçmişi
- G-Code listesi ve metadata analizi
- Yazıcıya kontrol komutu gönderilmez
