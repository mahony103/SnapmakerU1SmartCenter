# Snapmaker U1 Smart Center v0.9

Snapmaker U1 için salt-okunur yerel Wi-Fi izleme uygulaması.

- 4 nozzle anlık/hedef sıcaklık
- Tabla ve kabin sıcaklığı
- Aktif baskı ve ilerleme
- G-Code metadata
- Filament gram + renk + malzeme
- G-Code renk bazlı planlanan filament gramajı
- Baskı sırasında gerçek toplam filament kullanımı (tahmini)
- Baskı geçmişi
- Özel U1 ikonlu koyu arayüz

Uygulama yazıcıya komut göndermez.
