# Snapmaker U1 Smart Center V1.0

Snapmaker U1 için yerel Wi-Fi üzerinden salt-okunur Smart Center.

## V1.0
- Doğrudan Android projesidir; ZIP içinden ZIP açma yoktur.
- GitHub Actions doğrudan `:app:assembleDebug` çalıştırır.
- Uygulama sürümü V1.0 olarak gösterilir.
- G-Code `filament_weights` verileri renk/filament bazında ayrı gösterilir.
- Toplam planlanan gramaj tek bir renge atanmaz.
- Baskı sırasında gerçek toplam kullanım alınabiliyorsa "Kullanılan Filament", yalnızca plan mevcutsa "Kullanılacak Filament" başlığı kullanılır.

## GitHub
Bu klasörün içeriğini repository ana dizinine yükleyin. ZIP dosyasını repository'ye koyup workflow'un onu açması gerekmez.
